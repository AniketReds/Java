import java.util.*;
class Characters{
	public static void main(String args[]){
		String s;
		int n,i,c1=0,c2=0,sp=0,c3=0;
		char ch;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String:");
		s=sc.nextLine();
		n=s.length();
		for(i=0;i<n;i++){
			ch=s.charAt(i);
			if(Character.isLetter(ch))
				c1++;
			else if(Character.isDigit(ch))
				c2++;
			else if(ch==' ')
				sp++;
			else
				c3++;
		}
		System.out.println("No of Alphabets="+c1);
		System.out.println("No of Numbers="+c2);
		System.out.println("No of Spaces="+sp);
		System.out.println("No of Special Characters="+c3);
	}
}