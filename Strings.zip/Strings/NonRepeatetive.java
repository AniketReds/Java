import java.io.*;
class NonRepeatetive{
	public static void main(String args[])throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int w,k,c;
		System.out.println("Enter the String:");
		String s=br.readLine();
		int n=s.length();
		char []z = new char[n];
		for(w=0;w<n;w++){
			z[w]=s.charAt(w);
		}
		int i,j;
		char ch;
		for(i=0;i<w;i++){
			ch=z[i];
			for(j=i+1;j<w;j++){
				if(ch==z[j]){
					for(k=j;k<(w-1);k++){
						z[k]=z[k+1];
						w--;
						j=i;
					}
				}
			}
		}
		for(i=0;i<w;i++){
			for(j=0,c=0;j<n;j++){
				if(z[i]==s.charAt(j))
					c++;
			}
			System.out.print(z[i]);
		}
	}
}