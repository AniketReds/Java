package p2;

public class MyException extends Exception {
	public int x;
	public MyException(int y)throws MyException{
		super();
		x=y;
	}
	public void handler(){
		if(x==0){
			System.out.println("Balance should not be less than 2000.");
		}
		else if(x==1){
			System.out.println("Initial balance cannot be zero.");
		}
		else{
			System.out.println("Balance after withdraw cannot be less than zero.");
		}
	}
}
