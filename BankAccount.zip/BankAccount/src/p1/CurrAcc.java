package p1;
import p2.MyException;
public class CurrAcc extends Bank {
	void OpenAcc(int acc_number,double bal){
		if(count<10){
			acc_no[count]=acc_number;
			balance[count]=bal;
			System.out.println("Account Successfully Opened!!!");
			System.out.println("Account Number:"+acc_no[count]);
			System.out.println("Balance:"+balance[count]);
			count++;
		}
	}
	void withdraw(int acc,double amt){
		int flag=0;
		for(int i=0;i<count;i++){
			if(acc_no[i]==acc){
				if((balance[i]-amt)>2000){
					balance[i]-=amt;
					System.out.println("Transaction Successful!");
				}
				else{
					try{
						throw new MyException(0);
					}
					catch(MyException e){
						e.handler();
					}
					System.out.println("Insufficient Balance.");
				}
				System.out.println("Your Current Balance is:"+balance[i]);
				flag=1;
				break;
			}
		}
		if(flag!=1){
			System.out.println("No Such Account Found.Enter the correct account number");
		}
	}
	void deposit(int acc, double amt){
		int flag=0;
		for(int i=0;i<count;i++){
			if(acc_no[i]==acc){
				 if((balance[i]+amt)>2000){
					 balance[i]+=amt;
					 System.out.println("Transaction Successful!!Your Current Balance:"+balance[i]);
					 flag=1;
					 break;
				 }
			}
		}
		if(flag!=1){
			System.out.println("No such account is found. Enter the proper account number.");
		}
	}
	public int counter(){
		return count;
	}
	public void display(){
		for(int i=0;i<count;i++){
			System.out.println(acc_no[i]+"             "+balance[i]);
		}
	}
}
