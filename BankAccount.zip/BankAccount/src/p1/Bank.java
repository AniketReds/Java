package p1;

public abstract class Bank {
	int acc_no[]=new int[10];
	double balance[]=new double[10];
	int count=0;
	abstract void withdraw(int acc_no ,double amt);
	abstract void deposit(int acc_no,double amt);
}
