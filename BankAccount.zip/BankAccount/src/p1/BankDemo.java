package p1;
import java.io.*;
import p2.MyException;
public class BankDemo {
	public static void main(String[] args)throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int ch,acc_no=9999,account_number,count1,count2;
		double balance,amt;
		CurrAcc ob1=new CurrAcc();
		SavAcc ob2=new SavAcc();
		do{
			System.out.println("Enter 1. For Opening Current Account.");
			System.out.println("Enter 2. For Opening Savings Account.");
			System.out.println("Enter 3. For Withdrawing from Current Account.");
			System.out.println("Enter 4. For Depositing in Current Account.");
			System.out.println("Enter 5. For Withdrawing from Savings Account.");
			System.out.println("Enter 6. For Depositing in Savings Account.");
			System.out.println("Enter 7. For Displaying number of Accounts.");
			System.out.println("Enter 8. For Display.");
			System.out.println("Enter 0. For Exit.");
			System.out.print("Enter Your Choice:");
			ch=Integer.parseInt(br.readLine());
			System.out.println();
			switch(ch){
			case 1:
				System.out.println("Enter the Balance:");
				balance=Double.parseDouble(br.readLine());
				if(balance>2000){
					++acc_no;
					ob1.OpenAcc(acc_no,balance);
				}
				else{
					try{
						throw new MyException(0);
					}
					catch(MyException e){
						e.handler();
					}
					System.out.println("Account Not Opened!!");
				}
				break;
				
			case 2:
				System.out.println("Enter the Balance:");
				balance=Double.parseDouble(br.readLine());
				if(balance>0){
					++acc_no;
					ob2.OpenAcc(acc_no, balance);
				}
				else{
					try{
						throw new MyException(1);
					}
					catch(MyException e){
						e.handler();
					}
					System.out.println("Account Not Opened!!");
				}
				break;
				
			case 3:
				System.out.print("Enter the Account Number:");
				account_number=Integer.parseInt(br.readLine());
				System.out.print("\nEnter the amount to be withdrawn:");
				amt=Double.parseDouble(br.readLine());
				ob1.withdraw(account_number,amt);
				break;
				
			case 4:
				System.out.print("Enter the Account Number:");
				account_number=Integer.parseInt(br.readLine());
				System.out.print("\nEnter the amount to be withdrawn:");
				amt=Double.parseDouble(br.readLine());
				ob1.deposit(account_number,amt);
				break;
				
			case 5:
				System.out.print("Enter the Account Number:");
				account_number=Integer.parseInt(br.readLine());
				System.out.print("\nEnter the amount to be withdrawn:");
				amt=Double.parseDouble(br.readLine());
				ob2.withdraw(account_number,amt);
				break;
				
			case 6:
				System.out.print("Enter the Account Number:");
				account_number=Integer.parseInt(br.readLine());
				System.out.print("\nEnter the amount to be withdrawn:");
				amt=Double.parseDouble(br.readLine());
				ob2.deposit(account_number,amt);
				break;
				
			case 7:
				count1=ob1.counter();
				count2=ob2.counter();
				System.out.println("Number of Accounts are:-"+(count1+count2));
				break;
				
			case 8:
				System.out.println("Account Number    Balance");
				ob1.display();
				ob2.display();
				break;
				
			case 0:
				break;
				
			default:
				System.out.println("Invalid Choice!!!");
			}
		}while(ch!=0);
	}

}
