import java.util.*;
class EmployeeDemo{
	public static void main(String args[]){
		String name;
		Double salary,sales;
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the Name , Salary and Sales:");
		name=sc.next();
		salary=sc.nextDouble();
		sales=sc.nextDouble();
		Employee obj = new Pensioner(name,salary);
		obj.show();
		Employee obj1 = new Manager(name,salary,sales);
		obj1.show();
	}
}