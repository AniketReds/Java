class Employee{
	int employee_id;
	String name;
	double salary;
	int id=0;
	Employee(String name,double salary){
		employee_id=++id;
		this.name=name;
		this.salary=salary;
	}
	void show(){
		System.out.println();
		System.out.println("Employee_id="+employee_id+"\nName="+name+"\nSalary=
		"+salary);
	}
}
class Pensioner extends Employee{
	double pension;
	Pensioner(String name,double salary){
		super(name,salary);
		pension=0.60*salary;
	}
	void show(){
		super.show();
		System.out.println("Pension="+pension);
	}
}
class Manager extends Employee{
	double sales;
	double com;
	Manager(String name,double salary,double sales){
		super(name,salary);
		this.sales=sales;
		com=0.10*sales;
	}
	void show(){
		super.show();
		System.out.println("Sales="+sales+"\nCommission="+com);
	}
}
