public class DeptInfo{
	String dept_id;
	String dept_name;
	String dept_loc;
	public DeptInfo(String dept_id,String dept_name,String dept_loc){
		this.dept_id=dept_id;
		this.dept_name=dept_name;
		this.dept_loc=dept_loc;
	}
}