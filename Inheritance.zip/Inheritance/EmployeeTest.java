import java.util.*;
class EmployeeTest{
	public static void main(String args[]){
		String eid,name;
		float sal;
		String pos;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Employee ID, Employee Name,Position and Salary:-");
		eid=sc.next();
		name=sc.next();
		pos=sc.next();
		sal=sc.nextFloat();
		if((sal>=10000)&&(sal<20000)){
			DeptInfo d = new DeptInfo("D01","Software","Chicago");
			EmployeInfo e = new EmployeInfo(eid,name,pos,sal,d);
			e.anualSalary();
			e.display();
		}
		else{
			DeptInfo d = new DeptInfo("D02","Testing","Washington");
			EmployeInfo e = new EmployeInfo(eid,name,pos,sal,d);
			e.anualSalary();
			e.display();
		}	
	}
}