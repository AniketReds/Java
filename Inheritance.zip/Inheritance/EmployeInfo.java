public class EmployeInfo{
	String emp_name;
	String emp_id;
	String pos;
	float sal;
	float anual_sal;
	DeptInfo deptinfo;
	public EmployeInfo(String emp_id,String emp_name,String pos,float sal,DeptInfo deptinfo){
		this.emp_id=emp_id;
		this.emp_name=emp_name;
		this.pos=pos;
		this.sal=sal;
		this.deptinfo=deptinfo;
		anual_sal=0;
	}
	void anualSalary(){
		anual_sal=12*sal;
	}
	void display(){
		System.out.println("Employee ID:- "+emp_id);
		System.out.println("Employee Name:- "+emp_name);
		System.out.println("Position:- "+pos);
		System.out.println("Salary:- "+sal);
		System.out.println("Department ID:- "+deptinfo.dept_id);
		System.out.println("Department Name:- "+deptinfo.dept_name);
		System.out.println("Department Location:- "+deptinfo.dept_loc);
		System.out.println("Anual Salary:- "+anual_sal);
	}
}