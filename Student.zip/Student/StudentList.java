class StudentList{
	private Student[] list;
	int size,count;
	StudentList(int size){
		this.size=size;
		count=0;
		list=new Student[size];
	}
	public void AddStudent(Student s){
		if(count<size){
			list[count++]=s;
		}
	}
	public int searchByRoll(int i){
		int index=-1;
		for(int j=0;j<count;j++)
		{
			if(list[j].getRoll()==i)
			{
				index=j;
				break;
			}
		}
		return index;
	}
	public void showAll(){
		System.out.println("ROLL \t NAME \t MARKS");
		for(int i=0;i<count;i++)
			System.out.println(list[i].getRoll()+"\t"+list[i].getName()+"\t"+list[i].getMarks());
	}
	public Student getStudent(int i){
		if(i>count)
			return null;
		else
			return list[i];
	}
	public void sort(){
		Student temp;
		for(int i=0;i<count;i++){
			for(int j=0;j<count-i-1;j++){
				if(list[j].getRoll()>list[j+1].getRoll()){
					temp=list[j];
					list[j]=list[j+1];
					list[j+1]=temp;
				}
			}
		}
	}
	public void alternateSort(int option,boolean flag){
		boolean swapflag;
		Student s;
		for(int i=0;i<count;i++){
			for(int j=0;j<count-i-1;j++){
				swapflag=false;
				switch(option){
					case 1:
				swapflag=(flag)?(list[j].getRoll()>list[j+1].getRoll()):(list[j].getRoll()<list[j+1].getRoll());
				break;
				
					case 2:
				swapflag=(flag)?(list[j].getMarks()>list[j+1].getMarks()):(list[j].getMarks()<list[j+1].getMarks());
				break;
				
				}
				if(swapflag){
					s=list[j];
					list[j]=list[j+1];
					list[j+1]=s;
				}
			}
		}
	}
	public void delete(int roll){
			int index=this.searchByRoll(roll);
			if(index>=0){
				for(int i=index;i<count-1;i++){
					list[i]=list[i+1];
				}
				count--;
				list[count]=null;
			}
	}
	public int getCount(){
		return count;
	}
}