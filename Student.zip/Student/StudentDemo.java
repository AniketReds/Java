import java.util.*;
class StudentDemo{
	public static void main(String args[]){
		int n,choice,roll,marks,a;
		String name;
		Scanner sc = new Scanner(System.in);
		StudentList slist=null;
		Student s=null;
		System.out.println("Enter the Size:");
			n=sc.nextInt();
			slist=new StudentList(n);
			do{
				System.out.println("\n Enter 1. To Add Student.");
				System.out.println(" Enter 2. To Get Single Student details by roll number.");
				System.out.println(" Enter 3. To View All Student details.");
				System.out.println(" Enter 4. To get the details of a Single Student");
				System.out.println(" Enter 5. To Sort the Student Details by roll no. .");
				System.out.println(" Enter 6. To Sort the Student Details either by roll or by marks .");
				System.out.println(" Enter 7. To Delete the Student Details.");
				System.out.println(" Enter 8. To count the number of Students.");
				System.out.println(" Enter 0. To Exit");
				System.out.println("Enter Your Choice:-");
				choice=sc.nextInt();
				switch(choice){
					case 1:
					System.out.println("Enter the Roll , Name and Marks of a Student:");
					roll=sc.nextInt();
					name=sc.next();
					marks=sc.nextInt();
					s=new Student(roll,name,marks);
					slist.AddStudent(s);
					break;
				
					case 2:
					System.out.println("Enter the Roll number of a Student of which you want to see:");
					a=sc.nextInt();
					Student sd;
					int e;
						e=slist.searchByRoll(a);
						sd=slist.getStudent(e);
						System.out.println("ROLL \t NAME \t MARKS");
						System.out.println(sd.getRoll()+"\t"+sd.getName()+"\t"+sd.getMarks());
					break;
					
					
					case 3:
					slist.showAll();
					break;
					
					case 4:
					System.out.println("Enter the index number of a Student of which you want to see:");
					int k=sc.nextInt();
					int c=slist.getCount();
					Student st;
					if(k<c){
						st=slist.getStudent(k);
						System.out.println("ROLL \t NAME \t MARKS");
						System.out.println(st.getRoll()+"\t"+st.getName()+"\t"+st.getMarks());
					}
					else{
						System.out.println("Invalid Index Number!!!!");
						break;
					}
					break;
					
					case 5:
					System.out.println("The Sorted Result:");
					slist.sort();
					slist.showAll();
					break;
					
					case 6:
					System.out.println("Enter 1. To Sort by Roll.");
					System.out.println("Enter 2. To Sort by Marks.");
					int d=sc.nextInt();
					System.out.println("Enter True or False");
					boolean g =sc.nextBoolean();
					slist.alternateSort(d,g);
					slist.showAll();
					break;
					
					case 7:
						System.out.print("Enter the Roll:");
						int r=sc.nextInt();
						slist.delete(r);
						slist.showAll();
						break;
				
					case 8:
					int f=slist.getCount();
					System.out.print("Total Number of Students:-"+f );
					break;
					
				
					case 0:
					break;
				
					default:
					System.out.println("Invalid Choice!!");
				}
			}
			while(choice>0);
		
	}
}