class Student{
	private int roll;
	private int marks;
	private String name;
	public Student(int roll,String name,int marks){
			this.roll=roll;
			this.name=name;
			this.marks=marks;
	}
	public int getRoll(){
		return roll;
	}
	public String getName(){
		return name;
	}
	public int getMarks(){
		return marks;
	}
}