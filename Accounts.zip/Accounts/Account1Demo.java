import java.util.*;
class Account1Demo{
	public static void main(String args[]){
		int choice,id=0;
		double balance;
		String name;
		Scanner sc = new Scanner(System.in);
		Account1List alist=null;
		Account1 a=null;;
		System.out.println("Enter the Size:");
		int n=sc.nextInt();
		alist=new Account1List(n);
		do{
				System.out.println(" Enter 1. To Add Account.");
				System.out.println(" Enter 2. To get a sorted result in Ascending Order.");
				System.out.println(" Enter 3. To get a sorted result in Descending Order.");
				System.out.println(" Enter 4. To Show the whole Details.");
				System.out.println(" Enter 5. To get the details of the maximum balance holder .");
				System.out.println(" Enter 6. To get the details of an Account Holder by its ID.");
				System.out.println(" Enter 7. To deposit. ");
				System.out.println(" Enter 8. To Withdraw. ");
				System.out.println(" Enter 9. To show the details of an Account by its index number.");
				System.out.println(" Enter 10. To count the number of Accounts.");
				System.out.println(" Enter 0. To Exit");
				System.out.println("Enter Your Choice:-");
				choice=sc.nextInt();
				switch(choice){
					case 1:
					++id;
					System.out.println("Enter the Name and Balance:");
					name=sc.next();
					balance=sc.nextDouble();
					a=new Account1(id,name,balance);
					alist.addAccount(a);
					break;
					
					case 2:
					System.out.println("The Sorted Result in Ascending Order:-");
					alist.sortAsec();
					alist.showAll();
					break;
					
					case 3:
					System.out.println("The Sorted Result in Descending Order:-");
					alist.sortDesc();
					alist.showAll();
					break;
					
					case 4:
					alist.showAll();
					break;
					
					case 5:
					alist.maxbalance();
					break;
					
					case 6:
					System.out.println("Enter the ID:");
					int k=sc.nextInt();
					alist.SearchByID(k);
					break;
						
					case 7:
					System.out.println("Enter the id and name of the account:");
					int e=sc.nextInt();
					String nam=sc.next();
					System.out.println("Enter the amount to be deposited:");
					double amt=sc.nextDouble();
					alist.deposit(e,nam,amt);
					break;
					
					case 8:
					System.out.println("Enter the id and name of the account:");
					int v=sc.nextInt();
					String nam1=sc.next();
					System.out.println("Enter the amount to be Withdrawn:");
					double amt1=sc.nextDouble();
					alist.withdraw(v,nam1,amt1);
					break;
					
					case 9:
					System.out.println("Enter the Index value:-");
					int index = sc.nextInt();
					Account1 a1;
					int y =alist.counter();
					if(index<y){
						a1=alist.getAccount(index);
						System.out.println("Account_ID\tAccount_Holder\tBalance");
						System.out.println(a1.getID()+"\t\t"+a1.getName()+"\t\t"+a1.getBalance());
					}
					break;
					
					case 10:
					int f=alist.counter();
					System.out.print("Total Number of Accounts:-"+f );
					break;
					
					case 0:
					break;
					
					default:
					System.out.println("Invalid Choice!!");
				}
		}
		while(choice>0);
	}
}