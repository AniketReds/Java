class Account1List{
	private Account1[] list;
	int size,count;
	Account1List(int size){
		this.size=size;
		count=0;
		list= new Account1[size];
	}
	public void addAccount(Account1 a){
		if(count<size)
			list[count++]=a;
	}
	public Account1 getAccount(int k){
		if(k<count)
			return list[k];
		else 
			return null;
	}
	public void sortAsec(){
		Account1 ac;
			for(int m=0;m<count;m++){
				for(int j=0;j<count-m-1;j++){
					if(list[j].getBalance()>list[j+1].getBalance()){
						ac = list[j];
						list[j]=list[j+1];
						list[j+1]=ac;
					}
				}
			}
	}
	public void sortDesc(){
		Account1 ac1;
			for(int q=0;q<count;q++){
				for(int h=0;h<count-q-1;h++){
					if(list[h].getBalance()<list[h+1].getBalance()){
						ac1 = list[h];
						list[h]=list[h+1];
						list[h+1]=ac1;
					}
				}
			}
	}
	public void showAll(){
		System.out.println("Account_ID\tAccount_Holder\tBalance");
		for(int i=0;i<count;i++){
		System.out.println(list[i].getID()+"\t\t"+list[i].getName()+"\t\t"+list[i].getBalance());
		}
	}
	public int counter(){
		return count;
	}
	public void maxbalance(){
		int i;
		double max=list[0].getBalance();
		System.out.println("The First one:"+max);
		for(i=1;i<count;i++){
			if(list[i].getBalance()>max){
				max=list[i].getBalance();
			}
		}
		System.out.println("The Maximum Balance : "+max);
		System.out.println("Account_ID\tAccount_Holder\tBalance");
		for(int j=0;j<count;j++){
			if(list[j].getBalance()==max){
				System.out.println(list[j].getID()+"\t\t"+list[j].getName()+"\t\t"+list[j].getBalance());
			}
		}
	}
	public void SearchByID(int a){
		int i;
		for(i=0;i<count;i++){
			if(list[i].getID()==a){
				System.out.println("The Account Id:-"+i);
				System.out.println("Account_ID\tAccount_Holder\tBalance");
				System.out.println(list[i].getID()+"\t\t"+list[i].getName()+"\t\t"+list[i].getBalance());
				break;
			}
		}
	}
	public void deposit(int id, String name,double amt){
		int i;
		double bal=-1;
		for(i=0;i<count;i++){
			if(list[i].getID()==id && (list[i].getName()).equals(name)){
				bal=list[i].getBalance();
				if(bal+amt>1000){
					bal+=amt;
					list[i].setBalance(bal);
				}
				else{
					System.out.println("Insufficient Balance!!");
				}
			}
		}
	}
	public void withdraw(int id, String name,double amt){
		int i;
		double bal=-1;
		for(i=0;i<count;i++){
			if(list[i].getID()==id && (list[i].getName()).equals(name)){
			bal=list[i].getBalance();
				if(bal-amt>1000){
					bal-=amt;
					list[i].setBalance(bal);
				}
				else{
					System.out.println("Insufficient Balance!!");
				}
			}
		}
	}
}