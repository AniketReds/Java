class Account1{
	int aid;
	double balance;
	String name;
	Account1(int id,String nam, double bal){
		aid=id;
		name=nam;
		if(bal>1000){
			balance=bal;
		}
	}
	public int getID(){
		return aid;
	}
	public String getName(){
		return name;
	}
	public double getBalance(){
		return balance;
	}
	public void setBalance(double balance){
		this.balance = balance;
	}
}